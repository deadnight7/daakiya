oauth2client\.contrib\.django\_util\.models module
==================================================

.. automodule:: oauth2client.contrib.django_util.models
    :members:
    :undoc-members:
    :show-inheritance:
